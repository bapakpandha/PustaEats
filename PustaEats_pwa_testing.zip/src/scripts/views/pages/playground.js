const Playground = {
  async render() {
    return `
      
        <section></section>
        <section></section>
        test
      `;
  },

  async afterRender() {
    // Fungsi ini akan dipanggil setelah render()
  },
};

export default Playground;